import pygame
from pygame.color import THECOLORS

class Seed:
    def __init__(self):
        self.count = 0
        self.image = pygame.image.load(r'img/Seed.png')
        self.pos = (750, 0)

    def draw(self, screen):
        screen.blit(self.image, self.pos)
        font = pygame.font.SysFont('couriernew', 40)
        text = font.render(str(int(self.count)), True, THECOLORS['green'])
        screen.blit(text, [50, 550])