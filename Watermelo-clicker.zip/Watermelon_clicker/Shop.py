import pygame
from pygame.color import THECOLORS


class Shop:
    def __init__(self):
        self.cross_img = pygame.image.load(r'img/Cross.png')

        self.attack_img = pygame.image.load(r'img/Sword.png')
        self.attack_name = 'Повышение урона'
        self.attack_price = 10
        self.attack_pos = [100, 100]

        self.DPS_cost = 10
        self.DPS_img = pygame.image.load(r'img/Second.png')
        self.DPS_name = 'Автоатака'
        self.DPS_pos = [400, 100]

    def write(self, wr, color, screen, pos, size):
        font = pygame.font.SysFont('couriernew', size)
        text = font.render(str(wr), True, color)
        screen.blit(text, pos)

    def try_to_buy(self, type, balance):
        if type == 'click':
            if balance >= self.attack_price:
                self.attack_price *= 2
                return balance - self.attack_price / 2
            return balance
        elif type == 'auto':
            if balance >= self.DPS_cost:
                self.DPS_cost *= 2
                return balance - self.DPS_cost / 2
            return balance

    def draw(self, screen, seed):
        screen.blit(self.cross_img, [750, 0])
        self.write(f'У Вас на счету: {int(seed)} семечек', THECOLORS['white'], screen, [0, 0], 30)

        screen.blit(self.attack_img, self.attack_pos)
        pygame.draw.rect(screen, THECOLORS['gray'], [100, 300, 200, 50], 0)
        self.write(self.attack_name, THECOLORS['black'], screen, [100, 300], 22)

        screen.blit(self.DPS_img, self.DPS_pos)
        pygame.draw.rect(screen, THECOLORS['gray'], [400, 300, 200, 50], 0)
        self.write(self.DPS_name, THECOLORS['black'], screen, [400, 300], 22)